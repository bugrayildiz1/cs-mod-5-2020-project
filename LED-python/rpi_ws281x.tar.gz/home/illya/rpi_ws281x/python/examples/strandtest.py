#!/usr/bin/env python3
# rpi_ws281x library strandtest example
# Author: Tony DiCola (tony@tonydicola.com)
#
# Direct port of the Arduino NeoPixel library strandtest example.  Showcases
# various animations on a strip of NeoPixels.

import time
from rpi_ws281x import *
import argparse

# LED strip configuration:
LED_COUNT      = 100      # Number of LED pixels.
LED_PIN        = 18      # GPIO pin connected to the pixels (18 uses PWM!).
#LED_PIN        = 10      # GPIO pin connected to the pixels (10 uses SPI /dev/spidev0.0).
LED_FREQ_HZ    = 800000  # LED signal frequency in hertz (usually 800khz)
LED_DMA        = 10      # DMA channel to use for generating signal (try 10)
LED_BRIGHTNESS = 255     # Set to 0 for darkest and 255 for brightest
LED_INVERT     = False   # True to invert the signal (when using NPN transistor level shift)
LED_CHANNEL    = 0       # set to '1' for GPIOs 13, 19, 41, 45 or 53



# Define functions which animate LEDs in various ways.
def colorWipe(strip, color, wait_ms=50):
    """Wipe color across display a pixel at a time."""
    for i in range(strip.numPixels()):
        strip.setPixelColor(i, color)
        strip.show()
        time.sleep(wait_ms/1000.0)

def theaterChase(strip, color, wait_ms=50, iterations=10):
    """Movie theater light style chaser animation."""
    for j in range(iterations):
        for q in range(3):
            for i in range(0, strip.numPixels(), 3):
                strip.setPixelColor(i+q, color)
            strip.show()
            time.sleep(wait_ms/1000.0)
            for i in range(0, strip.numPixels(), 3):
                strip.setPixelColor(i+q, 0)

def wheel(pos):
    """Generate rainbow colors across 0-255 positions."""
    if pos < 85:
        return Color(pos * 3, 255 - pos * 3, 0)
    elif pos < 170:
        pos -= 85
        return Color(255 - pos * 3, 0, pos * 3)
    else:
        pos -= 170
        return Color(0, pos * 3, 255 - pos * 3)

def rainbow(strip, wait_ms=20, iterations=1):
    """Draw rainbow that fades across all pixels at once."""
    for j in range(256*iterations):
        for i in range(strip.numPixels()):
            strip.setPixelColor(i, wheel((i+j) & 255))
        strip.show()
        time.sleep(wait_ms/1000.0)

def rainbowCycle(strip, wait_ms=20, iterations=5):
    """Draw rainbow that uniformly distributes itself across all pixels."""
    for j in range(256*iterations):
        for i in range(strip.numPixels()):
            strip.setPixelColor(i, wheel((int(i * 256 / strip.numPixels()) + j) & 255))
        strip.show()
        time.sleep(wait_ms/1000.0)

def theaterChaseRainbow(strip, wait_ms=50):
    """Rainbow movie theater light style chaser animation."""
    for j in range(256):
        for q in range(3):
            for i in range(0, strip.numPixels(), 3):
                strip.setPixelColor(i+q, wheel((i+j) % 255))
            strip.show()
            time.sleep(wait_ms/1000.0)
            for i in range(0, strip.numPixels(), 3):
                strip.setPixelColor(i+q, 0)

def cyclon(strip, color, wait_ms=50):
    for k in range(30):
        for j in range (10):
            for i in range(strip.numPixels()):
                if(i==strip.numPixels()):
                    strip.setPixelColor(i, Color(0,0,0))
                    strip.show()
                strip.setPixelColor(i, color)
                strip.show() 
                time.sleep(wait_ms/1000.0)
                if(i>10):
                    strip.setPixelColor(i-10, Color(0,0,0))
                    strip.show()

def animation(strip, color,r,g,b, wait_ms=50):
    maincolor=max(r,g,b)
    for k in range(strip.numPixels()):
            strip.setPixelColor(k,color)
            strip.show()
    for j in range(30):
        for i in range(strip.numPixels()):
            strip.setPixelColor(i,color)
            if maincolor==r:
                g=g+50
                b=b+50
                strip.setPixelColor(i+5, Color(r, g+10, b+10)%255)
            if maincolor==g:
                r=r+50
                b=b+50
                strip.setPixelColor(i+5, Color(r+10, g, b+10)%255)
            else:
                strip.setPixelColor(i+5, Color(r+10, g+10, b)%255)
                r=r+50
                g=g+50
            strip.show()


def colorStrip(id,r,g,b,a, **kwargs):
    brightness=int(a)
    strip = Adafruit_NeoPixel(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, brightness, LED_CHANNEL)
    strip.begin()

    colorWipe(strip, Color(0,0,0), 10)
    if id==1:
        if r>=0:
            if g>=0:
                if b>=0:
                    colorWipe(strip, Color(r, g, b))
                        
                        
    elif id==2:
            rainbow(strip)
    elif id==3:
        if r>=0:
            if g>=0:
                if b>=0:
                    theaterChase(strip, Color(r, g, b))
    elif id==4:
        rainbowCycle(strip)
    elif id==5:
        theaterChaseRainbow(strip)
    elif id==6:
        if r>=0:
            if g>=0:
                if b>=0:
                    cyclon(strip, Color(r, g, b))                 
    elif id==7:
        if r>=0:
            if g>=0:
                if b>=0:
                    animation(strip, Color(r, g, b), r, g, b)
    elif id==0:
        colorWipe(strip, Color(0,0,0), 10)
    else:
        print('incorrect value for the id')


    
    

# Main program logic follows:
if __name__ == '__main__':
   
    # Intialize the library (must be called once before other functions).
    parser=argparse.ArgumentParser()
    parser.set_defaults(method = colorStrip)
    parser.add_argument('id', type=int)
    parser.add_argument('r', type=int)
    parser.add_argument('g', type=int)
    parser.add_argument('b', type=int)
    parser.add_argument('a', type=float)
    arguments = parser.parse_args()
    arguments.method(**vars(arguments))

    
    # Process arguments
    # parser = argparse.ArgumentParser()
    # FUNCTION_MAP = {'0' : colorWipe(strip, Color(0,0,0)), '1' : rainbow,'2' : theaterChase(strip, Color(127,127,127))}

    # parser.add_argument('id' , choices=FUNCTION_MAP.keys())
    # args = parser.parse_args()

    # funk = FUNCTION_MAP[args.id]
    # funk(strip)
    # parser.add_argument('integers', metavar='N', type=int, nargs='+')
    # values = parser.parse_args()
    # parser.add_argument('--rgb',const=colorWipe(strip, Color()))
    # parser.add_argument('-id2',action='theater chase white mode',const=theaterChase(strip, Color(127, 127, 127)))
    # args = parser.parse_args()

    # Create NeoPixel object with appropriate configuration.
    # print ('Press Ctrl-C to quit.')
    # if not args.clear:
    #     print('Use "-c" argument to clear LEDs on exit')

        
    # try:

        # for couner in range(1, 2):
        # while (True) :
            # print ('Color wipe animations.')
            # colorWipe(strip, Color(255, 0, 0))  # Red wipe
            # colorWipe(strip, Color(0, 255, 0))  # Blue wipe
            # colorWipe(strip, Color(0, 0, 255))  # Green wipe
            # print ('Theater chase animations.')
            # theaterChase(strip, Color(127, 127, 127))  # White theater chase
            # theaterChase(strip, Color(127,   0,   0))  # Red theater chase
            # theaterChase(strip, Color(  0,   0, 127))  # Blue theater chase
            # print ('Rainbow animations.')
            # rainbow(strip)
            # rainbowCycle(strip)
            # theaterChaseRainbow(strip)
            # colorWipe(strip, Color(0,0,0), 10)
# except KeyboardInterrupt:
#     if args.clear:
#         colorWipe(strip, Color(0,0,0), 10)